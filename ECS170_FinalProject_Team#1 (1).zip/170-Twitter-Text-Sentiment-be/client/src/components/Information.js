import React from 'react';
import { useNavigate } from 'react-router-dom';
import '../App.css';

function Information() {
  const navigate = useNavigate();

  return (
    <div className="information-page">
      <button className="back-button" onClick={() => navigate('/')}>
        Back to Analysis
      </button>
      
      <div className="info-container">
        <h1>Twitter Sentiment Analysis Project</h1>
        
        <section className="info-section">
          <h2>Introduction</h2>
          <p>
            Our team is committed to addressing growing mental health challenges within our society today. 
            Mental health is a critical aspect of the overall well-being of individuals, however it is often 
            overlooked until it reaches a crisis point. We saw a unique opportunity to leverage AI-driven 
            sentiment analysis to uncover patterns in emotional expression through a platform like Twitter, 
            where people commonly share their thoughts and feelings in real time. Our goal with this tool 
            is to provide users with valuable insights into mental health patterns enabling earlier support 
            and fostering a proactive approach to emotional well-being.
          </p>
        </section>

        <section className="info-section">
          <h2>Background</h2>
          <p>
            Sentiment analysis is a natural language processing (NLP) technique that determines the 
            emotional tone of textual content. It categorizes text into positive, neutral, or negative 
            sentiments. This capability is especially significant for assessing mental health trends 
            based on communication style, language usage, and emotional tone.
          </p>
          <p>
            Transformer-based models, such as RoBERTa (an optimized BERT pre-training approach), have 
            revolutionized NLP tasks by understanding the context and semantics of text. These models 
            perform well in tasks like sentiment classification by capturing the nuances in language, 
            making them suitable for analyzing tweets to extract meaningful emotional insights.
          </p>
        </section>

        <section className="info-section">
          <h2>Technical Implementation</h2>
          <h3>AI Technologies and Methods</h3>
          <ul>
            <li>RoBERTa-based model for sentiment analysis ("cardiffnlp/twitter-roberta-base-sentiment")</li>
            <li>Natural Language Processing (NLP) techniques for data preprocessing</li>
            <li>"j-hartmann/emotion-english-distilroberta-base" model for emotion detection</li>
          </ul>

          <h3>Data</h3>
          <ul>
            <li>Twitter API integration for real-time tweet extraction</li>
            <li>Processing of text, hashtags, timestamps, and metadata</li>
          </ul>

          <h3>Technologies Used</h3>
          <ul>
            <li>Frontend: React.js with Recharts for data visualization</li>
            <li>Backend: Node.js and Express</li>
            <li>Python Libraries: transformers library for RoBERTa model implementation</li>
            <li>Twitter Developer Tools for API access</li>
          </ul>
        </section>

        <section className="info-section">
          <h2>Discussion</h2>
          <p>
            The development and implementation of our AI-driven sentiment analysis tool provided 
            valuable insights into the technical and social significance of applying technology 
            to mental health. By analyzing user's tweets, our tool categorized emotional tones 
            and identified sentiment patterns over time. This provides a promising step towards 
            leveraging AI for mental healthcare. From a technical perspective we learned the 
            importance of preprocessing text data, using effective transformer models to capture 
            emotion related data, and working around API restrictions. This project also emphasized 
            the importance of a user-friendly web design. Developing an easy to navigate front-end 
            dashboard allowed us to display our insights in a practical manner.
          </p>
        </section>

        <section className="info-section">
          <h2>Team Contributions</h2>
          <div className="team-contributions">
            <ul>
              <li><strong>Mariam Faizan</strong>: Contributed to the front-end development of the application. Managed team coordination, assigning tasks and responsibilities to align with project goals effectively. Conducted research on emotional analysis using Hugging Face models, evaluating various options to identify the most suitable model for implementation. Integrated data by fetching tweets and metadata from the Twitter API, enabling the application to process and analyze social media insights.</li>
              <li><strong>Alizah Nauman</strong>: Created the webpage dashboard using figma and developed the sentiment analysis visuals</li>
              <li><strong>Shuaib Ahmed</strong>: Contributed heavily to back and frontend of the project. Researched and implemented both hugging face models into the application. Transitioned the bar chart from using dummy data to data actually generated from the models. Essentially connecting the emotion analysis data generated from the models to the frontend. Also was responsible for the frontend themes and structure implementation. Also incorporated the information section page. </li>
              <li><strong>Zareb Islam</strong>: Conducted research with other teammates to determine the most suitable sentiment analysis models which provided a strong foundation for the project. Also collaborated with team to organize and assign tasks, making sure there were balanced workloads and clear communication among group members. Contributions also focused on backend development. Implemented some backend code, including additional error-checking mechanisms to ensure smooth functionality within the backend infrastructure. </li>
              <li><strong>John Missal</strong>: Initially researched the different models we could use for the sentiment analysis feature. Then helped set up the front end and connected the model to the front end to fetch real time data instead of mock up data. Worked on improving the "Sentiment Over Time" graph, to also use real time data, show time stamps of each tweet and the overall sentiment score of the user at different times. </li>
              <li><strong>Saif Khan</strong>: Contributed to the development of the front end of the application, focusing specifically on the “Sentiment Over Time” analysis feature. Work involved creating a chart using React and Recharts to display sentiment trends based on Twitter data. This visualization provides users with clear insights into how their emotional tone has evolved over time.</li>
              <li><strong>Litika Anbaransan</strong>: Contributed to the front end development and design of the web application. Also helped with the presentation. </li>
              <li><strong>Sachin Subramanian</strong>: Contributed to the development of the application's front end, with a focus on the 'Emotional Analysis' feature. Specifically, implemented a bar chart using Recharts to visually represent and analyze prevalent emotions derived from Twitter data.</li>
            </ul>
          </div>
        </section>
      </div>
    </div>
  );
}

export default Information;